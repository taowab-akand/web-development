COMPLETE SHOE VIDEO FRAME SEQUENCE

239 frames, 24 fps, 1920 x 1080 pixels.
Format: WebP, quality 90/100, encoder method 6.
Source: Make_3D_shoe_animation_14f50c93_1080p.mp4

All original frames are included in order, with no resizing or added frames.
This edition uses high-quality lossy WebP compression to reduce download and
upload size. It is not pixel-identical to the lossless PNG edition.
Extract this ZIP and use frames/frame_000001.webp to frame_000239.webp.
Use a 24 fps playback rate when loading the image sequence.

The ZIP fits GitHub's 25 MiB per-file browser repository upload limit.
Uploading a ZIP to a repository stores the archive; GitHub does not unpack it.
For a website that loads individual frames, extract them before adding them
to your project, and use the .webp extension in your frame paths.
